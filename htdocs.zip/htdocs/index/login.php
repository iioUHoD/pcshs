<?php
   include("config.php");
   session_start();

  // echo "I'm IN";
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
     // echo "I'm IN 2";
      
      $myusername = mysqli_real_escape_string($db,$_POST['username']);
      $mypassword = md5(mysqli_real_escape_string($db,$_POST['password'])); 
      // $mypassword=md5('$mypass'); 
      
      $sql = "SELECT Email,Name FROM member WHERE Email = '$myusername' and Password = '$mypassword'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      //$active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
         //session_register("myusername");
         $_SESSION['login_user'] = $myusername;
         
         header("Location: Menu/home.php");
      }else {
         $error = "Your Login Name or Password is invalid";
         echo "<script language='javascript'>
         alert('Your Login Name or Password is invalid');
         window.location.href = 'index.html';
         </script>";

      }
   }
?>