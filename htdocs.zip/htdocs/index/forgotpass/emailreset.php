<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Reset Password</title>
  <link href='https://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  
      <link rel="stylesheet" href="../template/css/style.css">

  
</head>

<body>

  <div class="form">

      <div class="tab-content">
        <div id="reset">   
          <h1>Reset Password</h1>
    
          <form name="form1" action="ereset.php" method="post"  >
          
          <!-- <div class="top-row"> -->

          <div class="field-wrap">
            <label>
              Email<span class="req">*</span>
            </label>
            <input id="email" name="email" type="username" required autocomplete="off" />
          </div>
          

          <button  id="submit" type="submit" class="button button-block" />Send</button>
           </form>

        </div>

      
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  

  <script  src="template/js/index.js"></script>



</body>

</html>