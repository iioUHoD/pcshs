<?php

include('config.php');

// Passkey that got from link 
$passkey=$_GET['passkey'];

$tbl="member";
$password   = $_POST['password1'];

// Retrieve data from table where row that match this passkey 
$sql1="SELECT * FROM $tbl WHERE SID ='$passkey'";
$result1=mysqli_query($sql1);

// If successfully queried 
if($result1){

// Count how many row has this passkey
$count=mysqli_num_rows($result1);

// if found this passkey in our database, retrieve data from table "temp_members_db"
if($count==1){

$rows=mysqli_fetch_array($result1);
//$fname=$rows['fname'];
//$lname=$rows['lname'];
$email=$rows['email'];
//$password=$rows['password']; 


// Insert data that retrieves from "temp_members_db" into table "registered_members" 
$sql2="UPDATE $tbl SET Password='$password' WHERE SID='$passkey' ";
$result2=mysqli_query($sql2);
}

// if not found passkey, display message "Wrong Confirmation code" 
else {
// echo "Error";
echo "<script language='javascript'>
         alert('Error');
         window.location.href = '../index.html';
         </script>";
}

// if successfully moved data from table"temp_members_db" to table "registered_members" displays message "Your account has been activated" and don't forget to delete confirmation code from table "temp_members_db"
if($result2){

echo "<script language='javascript'>
         alert('Done');
         window.location.href = '../index.html';
         </script>";

// Delete information of this user from table "temp_members_db" that has this passkey 
//$sql3="DELETE FROM $tbl_name1 WHERE confirm_code = '$passkey'";
//$result3=mysql_query($sql3);

}

}
?>