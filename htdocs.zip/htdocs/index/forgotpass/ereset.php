<?php
   include("config.php");

  // echo "I'm IN";
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
     // echo "I'm IN 2";
      
      $myusername = mysqli_real_escape_string($db,$_POST['username']); 
      
      $sql = "SELECT Email FROM member WHERE Email = '$myusername' ";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $reset_code=md5(uniqid(rand())); 
      //$active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {

         $query = "UPDATE $member SET SID='$reset_code' WHERE Email = '$myusername'";
            //mysqli_query($query) or die(mysqli_error("Can't Connect to DB")); 

            if ($db->query($query) === TRUE) {
                  echo "<script language='javascript'>
                 alert('Check Your Email');
                 window.location.href = '../index.html';
                 </script>";
              }
    


         //--------------------------SEND MAIL FORM--------------------------------------

// send e-mail to ...
$to=$email;

// Your subject
$subject="Your reset password link here";

// From
$header="from: Thanos <thanos@gmail.com>";

// Your message
$message="Your Comfirmation link \r\n";
$message.="Click on this link to reset your password \r\n";
//-------------------CHANGE YOUR OWN WEBSITE-------------------------------------
$message.="http://192.168.64.2/econfirmation.php?passkey=$reset_code";


// send email
$sentmail = mail($to,$subject,$message,$header);


// if your email succesfully sent
if($sentmail){
echo "\r\nLink Has Been Sent To Your Email Address.";
}
else {
echo "\r\nCannot send link to your e-mail address";
}


      }else {
         echo "<script language='javascript'>
         alert('Your Email is invalid');
         window.location.href = '../index.html';
         </script>";

      }
   }
?>