<?php
include('../session.php');

if(!isset($_SESSION['login_user'])){ //if login in session is not set
    header("Location: ../index.html");
}

?>

<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
		<title>Project</title>
		<!-- <meta name="description" content="A sidebar menu as seen on the Google Nexus 7 website" />
		<meta name="keywords" content="google nexus 7 menu, css transitions, sidebar, side menu, slide out menu" /> -->
		<meta name="author" content="Codrops" />
		<link rel="shortcut icon" href="../favicon.ico">
		<link rel="stylesheet" type="text/css" href="css/normalize.css" />
		<link rel="stylesheet" type="text/css" href="css/demo.css" />
		<link rel="stylesheet" type="text/css" href="css/component.css" />
		<!-- <link href='https://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
   		 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
      <link rel="stylesheet" href="../template/css/style.css"> -->

		<script src="js/modernizr.custom.js"></script>
	</head>
	<body>
		<div class="container">
			<ul id="gn-menu" class="gn-menu-main">
				<li class="gn-trigger">
					<a class="gn-icon gn-icon-menu"><span>Menu</span></a>
					<nav class="gn-menu-wrapper">
						<div class="gn-scroller">
							<ul class="gn-menu">
								<li id="search" class="gn-search-item">
									<input placeholder="Search & Download" type="search" class="gn-search">
									<a class="gn-icon gn-icon-search"><span>Search</span></a>
								</li>
								<li id="upload"  ><a class="gn-icon gn-icon-archive">Upload</a></li>
								<li id="downloads" >
									<a class="gn-icon gn-icon-download">Approval Download Lists</a>
									<!-- <ul class="gn-submenu">
										<li><a class="gn-icon gn-icon-illustrator">Vector Illustrations</a></li>
										<li><a class="gn-icon gn-icon-photoshop">Photoshop files</a></li>
									</ul> -->
								</li>
								<li id="edit" ><a class="gn-icon gn-icon-cog">Edit Users</a></li>
								<li><a class="gn-icon gn-icon-help">Help</a></li>
								<!-- <li>
									<a class="gn-icon gn-icon-archive">Archives</a>
									<ul class="gn-submenu">
										<li><a class="gn-icon gn-icon-article">Articles</a></li>
										<li><a class="gn-icon gn-icon-pictures">Images</a></li>
										<li><a class="gn-icon gn-icon-videos">Videos</a></li>
									</ul>
								</li> -->
							</ul>
						</div><!-- /gn-scroller -->
					</nav>
				</li>
				<!-- <li><a href="http://tympanus.net/codrops">Codrops</a></li>
				<li><a class="codrops-icon codrops-icon-prev" href="http://tympanus.net/Development/HeaderEffects/"><span>Previous Demo</span></a></li> -->

				<li><a class="codrops-icon codrops-icon-drop" href="#"><span><i> Hello <?php echo $login_session2; ?></i></span></a></li>
				<li><a class="" href="../logout.php"><span><i><?php echo 'Logout'; ?></i></span></a></li>


			</ul>
			<header>
				<h1>Website for Uploading Reports<span>Please give me high score :) I'm begging you~</span></h1>	

			<h5 id="upload_c" action="upload.php" method="post" enctype="multipart/form-data">
				Select image to upload:
				<input type="file" name="fileToUpload" id="fileToUpload">
				<input type="submit" value="Upload Image" name="submit">
			</h5>
			</header> 

			<li>
				<?php

				include('../connect.php');


$query = "SELECT * FROM uploadfile ORDER BY fileID asc" or die("Error:" . mysqli_error()); 
 
$result = mysqli_query($connection, $query); 
 
//ใช้ตารางในการจัดข้อมูล    เราใส่code upload ใน header แล้ว ลองดู folder ีีupload
echo "<table border='1' align='center' width='500'>";
//หัวข้อตาราง
echo "<tr align='center' bgcolor='#CCCCCC'><td>ID</td><td>File</td><td>DateTime</td></tr>";
while($row = mysqli_fetch_array($result)) { 
  echo "<tr>";
  echo "<td align='center'>" .$row["fileID"] .  "</td> "; 
  //echo "<td><a href='.$row['fileupload']'>showfile</a></td> ";
  echo "<td>"  .$row["fileupload"] . "</td> ";  
  echo "<td align='center'>" .$row["DateTime"] .  "</td> ";
  echo "</tr>";
}
echo "</table>";
//5. close connection
// mysqli_close($con);
?>
</li>

			

		</div><!-- /container -->
		<script src="js/classie.js"></script>
		<script src="js/gnmenu.js"></script>
		
		<script>
			new gnMenu( document.getElementById( 'gn-menu' ) );

// document.getElementById('upload').style.display = "none";
			// function permission_user() {
				var my_var = `<?php echo $login_session3; ?>`;

   				 if (my_var.valueOf() == "GUEST") {
   				 	// console.log("Hello world!");
   				     document.getElementById('upload').style.display = "none";
   				     document.getElementById('downloads').style.display = "none"; 
   				     document.getElementById('edit').style.display = "none";  
      			
 			   } else if(my_var.valueOf() == "STUDENT"){
 			   		 document.getElementById('downloads').style.display = "none"; 
   				     document.getElementById('edit').style.display = "none"; 
 			   }
 			   else if(my_var.valueOf() == "TEACHER"){
   				   	 document.getElementById('edit').style.display = "none"; 
 			   }
 			   else {
   				   
 			   }
			// }
		
		</script>
	</body>
</html>