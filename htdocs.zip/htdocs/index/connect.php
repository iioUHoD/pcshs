<?php
include('config.php');

$connection = $db;

if (!$connection){
    die("Database Connection Failed" . mysqli_error($connection));
}

?>