
<?php
include('config.php');
session_start();
//echo "Hello noob";
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
} 

        $fname      = $_POST['fname'];
        $lname      = $_POST['lname'];
        $email      = $_POST['email1'];
        $password   = $_POST['password1'];
        $confirm_code=md5(uniqid(rand())); 

        //echo $fname;

        $query = "SELECT Email FROM member where Email='".$email."'";
        $result = mysqli_query($db,$query);
        $numResults = mysqli_num_rows($result);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) // Validate email address
        {
            $message =  "Invalid email address please type a valid email!!";
            //echo $message;
            echo "<script language='javascript'>
            alert('Invalid email address please type a valid email!!');
            window.location.href = 'index.html';
            </script>";
            //header("Location: index.html");
        }
        elseif($numResults>=1)
        {
            $message = $email." Email already exist!!";
            //echo $message;
            echo "<script language='javascript'>
            alert('Email already exist!!');
            window.location.href = 'index.html';
            </script>";
             //header("Location: index.html");
        }
        else
        {
            $query = "insert into member (Name,Lname,Email,Password,SID) values ('".$fname."','".$lname."','".$email."','".md5($password)."','".$confirm_code."')";
            //mysqli_query($query) or die(mysqli_error("Can't Connect to DB")); 

            if ($db->query($query) === TRUE) {
                 // echo "New record created successfully\r\n";
                 // echo "Please check your email to activate your account";
                 // header("Location: Menu/home.php");
                 echo "<script language='javascript'>
                        alert('New record created successfully, Please check your email to activate your account.');
                         window.location.href = 'Menu/home.php';
                          </script>";

//--------------------------SEND MAIL FORM--------------------------------------

// send e-mail to ...
$to=$email;

// Your subject
$subject="Your confirmation link here";

// From
$header="from: Thanos <thanos@gmail.com>";

// Your message
$message="Your Comfirmation link \r\n";
$message.="Click on this link to activate your account \r\n";
//-------------------CHANGE YOUR OWN WEBSITE-------------------------------------
$message.="http://192.168.64.2/confirmation.php?passkey=$confirm_code";


// send email
$sentmail = mail($to,$subject,$message,$header);


// if your email succesfully sent
if($sentmail){
echo "\r\nYour Confirmation link Has Been Sent To Your Email Address.";
}
else {
echo "\r\nCannot send Confirmation link to your e-mail address";
}



//------------------------------------------------------------------------------

            } else {
                 echo "Error: " . $query . "<br>" . $db->error;
            }
            
        }

?>