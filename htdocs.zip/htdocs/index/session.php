<?php
   include('config.php');
   session_start();
   
   $user_check = $_SESSION['login_user'];

   // var_dump($user_check);
   
   $ses_sql = mysqli_query($db,"select Email from member where Email = '$user_check' ");
   $ses_sql2 = mysqli_query($db,"select Name from member where Email = '$user_check' ");
   $ses_sql3 = mysqli_query($db,"select Status from member where Email = '$user_check' ");
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   $row2 = mysqli_fetch_array($ses_sql2,MYSQLI_ASSOC);
   $row3 = mysqli_fetch_array($ses_sql3,MYSQLI_ASSOC);
   
   $login_session = $row['Email'];
   $login_session2 = $row2['Name'];
   $login_session3 = $row3['Status'];
   
   if(!isset($_SESSION['login_user'])){
      header("location: ../index.html");
      die();
   }
?>



