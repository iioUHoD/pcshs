<?php
$con= mysqli_connect("localhost","root","","testup") or die("Error: " . mysqli_error($con));

mysqli_query($con, "SET NAMES 'utf8' ");
 
?>